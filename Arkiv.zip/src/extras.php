<?php

class Bedpress{
  public static function kanBliMed($studieretninger, $arstrinn){
      $user_id = get_current_user_id();

    if(! in_array(get_the_author_meta('studieretning', $user_id), $studieretninger)){
      return false;
    }
    
    $klasse = self::getKlasse(get_the_author_meta('kull', $user_id));
    $riktigTrinn = false;
    foreach($arstrinn as $trinn){
      if( intval($trinn) == $klasse){
        $riktigTrinn = true;
      }
    }

    return $riktigTrinn;
  }
  public static function erMed($pameldte){
    if(! is_array($pameldte))
      return false;
    $id = get_current_user_id();
    foreach($pameldte as $bruker){
      if($id == $bruker["ID"])
        return true;
    }
    return false;
  }
  private static function sjekkKanBliMed($post_id){
    return self::kanBliMed(get_field('apent_for', $post_id),  get_field('trinn', $post_id));
  }
  private static function getKlasse($kull){
    return floor((time() - strtotime($kull.'-07-07')) / 31556926) + 1;
  }
  private static function meldPaa($user_id, $post_id){
      if(! self::sjekkKanBliMed($post_id))
        return false;
      ACFUpdater::leggTil('pameldte', $user_id, $post_id);
  }
  private static function meldAv($user_id, $post_id){
    ACFUpdater::fjern('pameldte', $user_id, $post_id);
  }
  public static function handlePost(){
    if(!isset($_POST) && !empty($_POST))
      return false;
    if(!isset($_POST['bruker']) && empty($_POST['bruker']))
      return false;
    if(!isset($_POST['handling']) && empty($_POST['handling']))
      return false;
    if(!isset($_POST['bedriftspresentasjon']) && empty($_POST['bedriftspresentasjon']))
      return false;
    switch($_POST['handling']){
      case "meld_paa":
        self::meldPaa($_POST['bruker'], $_POST['bedriftspresentasjon']);
        break;
      case "meld_av":
        self::meldAv($_POST['bruker'], $_POST['bedriftspresentasjon']);
        break;
    }
  }
  public static function hentStatus($pameldte){
    if(self::erMed($pameldte)){
      return "Du er meldt på denne bedriftspresentasjonen!";
    }
    return false;// Han er ikke påmeldt
  }
}

class Arrangement{
  public static function erMed($pameldte){
    if(! is_array($pameldte))
      return false;
    $id = get_current_user_id();
    foreach($pameldte as $bruker){
      if($id == $bruker["ID"])
        return true;
    }
    return false;
  }
  public static function kanBliMed(){
    return true;
  }
  private static function meldPaa($bruker_id, $post_id){
      ACFUpdater::leggTil('pameldte', $bruker_id, $post_id);
  }
  private static function meld_av($bruker_id, $post_id){
      ACFUpdater::fjern('pameldte', $bruker_id, $post_id);
  }
  public static function handlePost(){
    if(!isset($_POST) && !empty($_POST))
      return false;
    if(!isset($_POST['bruker']) && empty($_POST['bruker']))
      return false;
    if(!isset($_POST['handling']) && empty($_POST['handling']))
      return false;
    if(!isset($_POST['arrkom']) && empty($_POST['arrkom']))
      return false;
    switch($_POST['handling']){
      case "meld_paa":
        self::meldPaa($_POST['bruker'], $_POST['arrkom']);
        break;
      case "meld_av":
        self::meldAv($_POST['bruker'], $_POST['arrkom']);
        break;
    }
  }
  public static function hentStatus($pameldte, $betalte, $pris){
    if($pris == 0){
      // Det er gratis - bare tenk på påmeldte
      if(self::erMed($pameldte)){
        return "Du er allerede meldt på!";
      }
    }else{
      // Det koster penger, her er det de betalte som gjelder
      if(self::erMed($betalte)){
        return "Du er meldt på og din betaling er registrert!";
      }else if(self::erMed($pameldte)){
        return "Du er meldt på men din betaling er ikke registrert enda";
      }
    }
    return false;// Han er ikke påmeldt
  }
}

class ACFUpdater{
  private static function arrayToId($arr){
      if(!is_array($arr))
        $arr = [];
      $lengde = count($arr);
      for($i = 0; $i < $lengde; $i++){
        $arr[$i] = $arr[$i]["ID"];
      }
      return $arr;
  }
  public static function leggTil($field_name, $verdi, $post_id){
      $verdier = self::arrayToID(get_field($field_name, $post_id));
      $key = array_search($verdi, $verdier);
      if ($key != NULL || $key !== FALSE)
        return; // Verdi allerede lagt til
      array_push($verdier, $verdi);
      update_field($field_name, $verdier, $post_id);
  }
  public static function fjern($field_name, $verdi, $post_id){

    $verdier = self::arrayToID(get_field($field_name, $post_id));
    $key = array_search($verdi, $verdier);
    if (! ($key != NULL || $key !== FALSE))
      return; // Verdi finnes ikke
    unset($verdier[$key]);
    update_field($field_name, $verdier, $post_id);
  }
}