@extends('layouts.base')

@section('content')

  <div class="seksjon">
    <div class="seksjon__holder">
      <h1>Kompendier</h1>
      @include('partials.kompendier')
    </div>
  </div>
@endsection