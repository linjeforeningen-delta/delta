{{ Bedpress::handlePost() }}
<?php $status = Bedpress::hentStatus(get_field('pameldte')); ?>
<div class="seksjon {{ $status? 'seksjon--infofelt' : ''}}">
<div class="seksjon__holder">
<article class="bedpress">
@if($status)
  <div class="infofelt">
    {{ $status }}
  </div>
@endif
  <aside class="sideboks">
    {!! the_post_thumbnail( null, 'full' ) !!}
    <div class="infoboks">
      <div class="infoboks__sted">
        <span>{{ get_field('sted') }}</span>
      </div>
      <div class="infoboks__dato">
        <time datetime="{{ get_field('tidspunkt') }}">{{ date('d. F Y',strtotime(get_field('tidspunkt'))) }}</time>
      </div>
      <div class="infoboks__tidspunkt">
        <time datetime="{{ get_field('tidspunkt') }}">{{ date('H:i',strtotime(get_field('tidspunkt'))) }}</time>
      </div>
      <div class="infoboks__plasser">
        <span>{{ get_field('tilgjengelige_plasser') }} Plasser</span>
        <progress max="{{ get_field('tilgjengelige_plasser') }}" value="{{ count(get_field('pameldte'))}}"></progress>
      </div>
      <div class="infoboks__trinn">
        <span><?php
          $alle_trinn = get_field('trinn');
          echo $alle_trinn[0] . " - " . end($alle_trinn) . " klasse";
        ?></span>
        <span>
        @if(in_array('matematikk', get_field('apent_for')))
          Matematikk 
        @else
          <span class="infoboks__trinn--skjul">Matematikk</span>
        @endif
        @if(count(get_field('apent_for')) < 2)
          <span class="infoboks__trinn--skjul">&#47;&#47; </span>
        @else
          &#47;&#47; 
        @endif
        @if(in_array('fysikk', get_field('apent_for')))
          Fysikk
        @else
          <span class="infoboks__trinn--skjul">Fysikk</span>
        @endif
        </span>
      </div>
      <div class="infoboks__knapp">
        @if( ! is_user_logged_in())
          <a href="{{ get_permalink( woocommerce_get_page_id( 'myaccount' ) ) }}" class="showlogin">Logg inn</a>
        @elseif(Bedpress::erMed(get_field('pameldte')))
          <form method="post">
          <input type="submit" value="Meld av">
          <input type="hidden" name="handling" value="meld_av">
            <input type="hidden" name="bruker" value="{{get_current_user_id() }}">
            <input type="hidden" name="bedriftspresentasjon" value="{{get_the_ID() }}">
          </form>
        @elseif(Bedpress::kanBliMed(get_field('apent_for'), get_field('trinn')))
          <form method="post">
            <input type="submit" value="Meld meg på">
            <input type="hidden" name="handling" value="meld_paa">
            <input type="hidden" name="bruker" value="{{get_current_user_id() }}">
            <input type="hidden" name="bedriftspresentasjon" value="{{get_the_ID() }}">
          </form>
        @else
          <button disabled="disabled">Kan ikke bli med</button>
        @endif
      </div>
    </div>
  </aside>
  <header>
    <hgroup>
      <h1>{{ get_the_title() }}</h1>
      <h2>Bedriftspresentasjon</h2>
    </hgroup>
  </header>
  <div>
    {!! the_content() !!}
  </div>
  <footer>
    {!! wp_link_pages(['before' => '<nav class="page-nav"><p>' . __('Pages:', 'sage'), 'after' => '</p></nav>']) !!}
  </footer>
</article>
</div>
</div>
<div class="seksjon seksjon--gronn bedpress__kart">
<div class="seksjon__holder">
  <h1>Sted for bedpress</h1>
  {!! get_field('sted_lenke') !!}
</div>
</div>