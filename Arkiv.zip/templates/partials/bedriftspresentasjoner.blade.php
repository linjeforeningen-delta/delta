  <?php
    $args = ['post_type' => 'bedpress', 'posts_per_page' => 3];
    $bedpresser = new WP_Query($args);
  ?>
  <div class="bedriftspresentasjoner">
  @while ($bedpresser->have_posts()) @php($bedpresser->the_post())
    @include ('partials.content-bedpress')
  @endwhile
  </div>