{{Arrangement::handlePost()}}
<?php $resultat = Arrangement::hentStatus(get_field('pameldte'), get_field('betalte'), get_field('pris_delta')); ?>
<div class="seksjon seksjon--bilde">
  {!! get_the_post_thumbnail( null, 'full' ) !!}
</div>
<div class="seksjon {{ $resultat? 'seksjon--infofelt' : ''}}">
<div class="seksjon__holder">
<article class="arrangement">

@if($resultat)
  <div class="infofelt">
    {{ $resultat }}
  </div>
@endif
  <aside class="sideboks">
    <div class="infoboks">
      <div class="infoboks__sted">
        <span>{{ get_field('sted') }}</span>
      </div>
      <div class="infoboks__dato">
        <time datetime="{{ get_field('tidspunkt') }}">{{ date('d. F Y',strtotime(get_field('tidspunkt'))) }}</time>
      </div>
      <div class="infoboks__tidspunkt">
        <time datetime="{{ get_field('tidspunkt') }}">{{ date('H:i',strtotime(get_field('tidspunkt'))) }}</time>
      </div>
      <div class="infoboks__pris">
        <span>{{ get_field('pris_delta') }},- &nbsp; // {{ get_field('pris_andre') }},-<br>
        <span class="infoboks__pris__forklaring">
          Deltagere // andre
        </span>
        </span>
      </div>
      <div class="infoboks__kleskode">
        <span>{{ get_field('kleskode') }}</span>
      </div>
      <div class="infoboks__knapp">
        @if( ! is_user_logged_in())
          <a href="{{ get_permalink( woocommerce_get_page_id( 'myaccount' ) ) }}" class="showlogin">Logg inn</a>
        @elseif(Arrangement::erMed(get_field('pameldte')))
          <button disabled="disabled">Allerede påmeldt</button>
        @elseif(Arrangement::kanBliMed())
          <form method="post">
            <input type="submit" value="Meld meg på">
            <input type="hidden" name="handling" value="meld_paa">
            <input type="hidden" name="bruker" value="{{get_current_user_id() }}">
            <input type="hidden" name="arrkom" value="{{get_the_ID() }}">
          </form>
        @else
          <button disabled="disabled">Kan ikke bli med</button>
        @endif
      </div>
    </div>
  </aside>
  <header>
      <h1>{{ get_the_title() }}</h1>
  </header>
  <div>
    {!! the_content() !!}
  </div>
  <footer>
    {!! wp_link_pages(['before' => '<nav class="page-nav"><p>' . __('Pages:', 'sage'), 'after' => '</p></nav>']) !!}
  </footer>
</article>
</div>
</div>
<div class="seksjon seksjon--gronn">
<div class="seksjon__holder">
  <h1>Andre arrangementer</h1>
  <?php 
    $args = ['post_type' => 'arrangement', 'posts_per_page' => 3, 'post__not_in' => [get_the_ID()]];
    $arrangementer = new WP_Query($args);
  ?>
  <div class="arkivside">
    @while($arrangementer->have_posts()) <?php $arrangementer->the_post(); ?>
      @include ('partials.content-arrangement')
    @endwhile
  </div>
  <div class="seksjon__lenke"><a href="{{ get_post_type_archive_link('arrangement') }}">Se flere</a></div>
</div>
</div>