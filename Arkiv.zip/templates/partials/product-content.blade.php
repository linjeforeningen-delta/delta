
  <header>
    <h1 class="entry-title">{{ get_the_title() }}</h1>
  </header>
  <div>
    @php(the_content())
  </div>