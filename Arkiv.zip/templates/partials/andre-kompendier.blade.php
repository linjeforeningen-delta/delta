
  <div class="seksjon seksjon--gronn">
    <div class="seksjon__holder">
      <h1>Andre kompendier</h1>
      @include('partials.kompendier')
    </div>
  </div>