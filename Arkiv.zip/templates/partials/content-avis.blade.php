<div class="trippel__enkel">
  <a href="{{ get_permalink() }}">
    {!! get_the_post_thumbnail( null, 'full' ) !!}
    <h3>{{ get_the_title() }}</h3>
  </a>
</div>