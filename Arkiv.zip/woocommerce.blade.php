@extends('layouts.base')

@section('content')
  @php(woocommerce_content())
@endsection
